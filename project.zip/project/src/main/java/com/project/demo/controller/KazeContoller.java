package com.project.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.project.demo.model.Kaze;
import com.project.demo.service.KazeService;




@RestController
public class KazeContoller {

	@Autowired
	KazeService kService;
	@GetMapping(value="/fetchItems")
	public List<Kaze> getAllItems() {
		List<Kaze> itemList=kService.getAllItems();
		return itemList;
	}
	@PostMapping(value="/saveItems")
	public Kaze saveItems(@RequestBody Kaze s) {
		return kService.saveItems(s);
	}
	@PutMapping(value="/updateItems")
	public Kaze updateItems(@RequestBody Kaze s) {
		return kService.saveItems(s);
	}
	@DeleteMapping("/deleItems/{ino}")
	public void deleteItems(@PathVariable("ino") int itemno){
		kService.deleteItems(itemno);
	}
	@GetMapping(value="/getItems/{ino}")
	public Kaze getItems(@PathVariable("ino") int itemno){
		return kService.getItems(itemno);
	}
}

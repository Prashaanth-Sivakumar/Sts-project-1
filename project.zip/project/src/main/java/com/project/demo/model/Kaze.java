package com.project.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Kaze {
	public int getItemNo() {
		return itemNo;
	}
	public void setItemNo(int itemNo) {
		this.itemNo = itemNo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getOffer() {
		return offer;
	}
	public void setOffer(String offer) {
		this.offer = offer;
	}
	public double getYouSaved() {
		return youSaved;
	}
	public void setYouSaved(int youSaved) {
		this.youSaved = youSaved;
	}
	@Id
	private int itemNo;
	@Column
	private String type;
	@Column
	private String name;
	@Column
	private double price;
	@Column
	private	 String offer;
	@Column
	private double youSaved;
}

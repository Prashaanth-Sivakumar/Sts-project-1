package com.project.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.demo.model.Kaze;
import com.project.demo.repository.KazeRepository;

@Service
public class KazeService {

	@Autowired
	KazeRepository kRepository;
	public List<Kaze> getAllItems() {
		List<Kaze> itemList=kRepository.findAll();
		return itemList;
	}
	public Kaze saveItems(Kaze s) {
		return kRepository.save(s);
	}
	public Kaze updateStudent(Kaze s) {
		return kRepository.save(s);
	}
	public void deleteItems(int itemno) {
		kRepository.deleteById(itemno);
	}
	public Kaze getItems(int itemno) {
		return kRepository.findById(itemno).get();
	}

}
